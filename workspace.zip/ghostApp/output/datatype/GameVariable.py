#!/usr/bin/python2
# -*- coding: utf-8 -*-

class GameVariable:

	def __init__(self, type):
		self.type = type

